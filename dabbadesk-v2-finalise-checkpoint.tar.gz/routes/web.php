<?php

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DraftOrdersController;
use App\Http\Controllers\MoneyDeskController;
use App\Http\Controllers\OrderRequestsController;
use App\Http\Controllers\OrdersController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\PublicIntakeSupportController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return redirect()->route('login');
});

Route::middleware(['auth', 'verified'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    Route::get('/orders', [OrdersController::class, 'index'])->name('orders.index');
    Route::get('/orders/{order}', [OrdersController::class, 'show'])->name('orders.show');

    Route::get('/order-requests', [OrderRequestsController::class, 'index'])->name('order-requests.index');
    Route::get('/order-requests/counter', [OrderRequestsController::class, 'counter'])->name('order-requests.counter');
    Route::get('/order-requests/{orderRequest}', [OrderRequestsController::class, 'show'])->name('order-requests.show');
    // Backward-compatible alias used by earlier conversion/review packs.
    Route::get('/order-requests/{orderRequest}/review', [OrderRequestsController::class, 'show'])->name('order-requests.review');
    Route::post('/order-requests/{orderRequest}/convert', [OrderRequestsController::class, 'convert'])->name('order-requests.convert');

    Route::get('/draft-orders', [DraftOrdersController::class, 'index'])->name('draft-orders.index');
    Route::post('/draft-orders/detect-retailer', [DraftOrdersController::class, 'detectRetailer'])->name('draft-orders.detect-retailer');
    Route::get('/draft-orders/{draftOrder}', [DraftOrdersController::class, 'show'])->name('draft-orders.show');
    Route::post('/draft-orders/detect-retailer', [DraftOrdersController::class, 'detectRetailer'])->name('draft-orders.detect-retailer');
    Route::post('/draft-orders/retailers/quick-store', [DraftOrdersController::class, 'quickStoreRetailer'])->name('draft-orders.retailers.quick-store');
    Route::patch('/draft-orders/{draftOrder}', [DraftOrdersController::class, 'update'])->name('draft-orders.update');
    Route::post('/draft-orders/{draftOrder}/items', [DraftOrdersController::class, 'addItem'])->name('draft-orders.items.store');
    Route::patch('/draft-orders/{draftOrder}/items/{item}', [DraftOrdersController::class, 'updateItem'])->name('draft-orders.items.update');
    Route::patch('/draft-orders/{draftOrder}/retailers/{retailer}/delivery', [DraftOrdersController::class, 'updateRetailerDelivery'])->name('draft-orders.retailers.delivery.update');
    Route::delete('/draft-orders/{draftOrder}/items/{item}', [DraftOrdersController::class, 'deleteItem'])->name('draft-orders.items.destroy');
    Route::post('/draft-orders/{draftOrder}/notes', [DraftOrdersController::class, 'addNote'])->name('draft-orders.notes.store');

    Route::get('/money-desk', [MoneyDeskController::class, 'index'])->name('money-desk.index');
    Route::get('/money-desk/customer-search', [MoneyDeskController::class, 'customerSearch'])->name('money-desk.customer-search');
    Route::get('/money-desk/order-search', [MoneyDeskController::class, 'orderSearch'])->name('money-desk.order-search');
    Route::get('/money-desk/anomalies', [MoneyDeskController::class, 'anomalies'])->name('money-desk.anomalies');
    Route::get('/money-desk/customers/{customer}', [MoneyDeskController::class, 'customerShow'])->name('money-desk.customers.show');
    Route::get('/money-desk/orders/{order}', [MoneyDeskController::class, 'orderShow'])->name('money-desk.orders.show');
});

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

Route::prefix('public/intake')->name('public.intake.')->group(function () {
    Route::post('/detect-retailer', [PublicIntakeSupportController::class, 'detectRetailer'])->name('detect-retailer');
    Route::get('/fee-policy', [PublicIntakeSupportController::class, 'feePolicy'])->name('fee-policy');
    Route::post('/submit', [PublicIntakeSupportController::class, 'submit'])->name('submit');
    Route::get('/countries', [PublicIntakeSupportController::class, 'countries'])->name('countries');
});

require __DIR__ . '/auth.php';
